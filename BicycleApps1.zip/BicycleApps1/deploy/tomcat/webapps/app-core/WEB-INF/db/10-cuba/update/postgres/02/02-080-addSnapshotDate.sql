
alter table SYS_ENTITY_SNAPSHOT add column SNAPSHOT_DATE timestamp^