alter table SYS_CATEGORY_ATTR add WIDTH varchar(20)^
alter table SYS_CATEGORY_ATTR add ROWS_COUNT integer^