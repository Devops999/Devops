alter table SEC_ENTITY_LOG add STRING_ENTITY_ID varchar(255)^
alter table SEC_ENTITY_LOG add INT_ENTITY_ID integer^
alter table SEC_ENTITY_LOG add LONG_ENTITY_ID bigint^