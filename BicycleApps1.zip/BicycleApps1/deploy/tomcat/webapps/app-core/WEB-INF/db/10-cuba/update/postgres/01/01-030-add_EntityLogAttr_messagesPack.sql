-- Description: adding SEC_ENTITY_LOG_ATTR.MESSAGES_PACK field

alter table SEC_ENTITY_LOG_ATTR add MESSAGES_PACK varchar(200)
^
