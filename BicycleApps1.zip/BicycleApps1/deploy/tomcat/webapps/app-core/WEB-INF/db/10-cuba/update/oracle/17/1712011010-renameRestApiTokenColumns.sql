alter table SYS_REST_API_TOKEN rename column ACCESS_TOKEN_VALUE to TOKEN_VALUE^
alter table SYS_REST_API_TOKEN rename column ACCESS_TOKEN_BYTES to TOKEN_BYTES^
alter table SYS_REST_API_TOKEN drop column CREATED_BY^