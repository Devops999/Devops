-- Increase length of SEC_CONSTRAINT columns

alter table SEC_CONSTRAINT alter column GROOVY_SCRIPT varchar(max)^

alter table SEC_CONSTRAINT alter column FILTER_XML varchar(max)^
