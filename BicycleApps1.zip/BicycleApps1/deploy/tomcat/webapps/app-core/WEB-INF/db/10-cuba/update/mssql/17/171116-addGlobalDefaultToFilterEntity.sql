alter table SEC_FILTER add GLOBAL_DEFAULT tinyint^
update SEC_FILTER set GLOBAL_DEFAULT = 0^
