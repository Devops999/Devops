alter table SEC_CONSTRAINT add IS_ACTIVE boolean default true^

