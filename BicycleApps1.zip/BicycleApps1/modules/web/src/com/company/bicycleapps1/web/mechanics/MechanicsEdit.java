package com.company.bicycleapps1.web.mechanics;

import com.haulmont.cuba.gui.components.AbstractEditor;
import com.company.bicycleapps1.entity.Mechanics;

public class MechanicsEdit extends AbstractEditor<Mechanics> {
}