package com.company.bicycleapps1.web.sparepart;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class SparePartBrowse extends AbstractLookup {
}