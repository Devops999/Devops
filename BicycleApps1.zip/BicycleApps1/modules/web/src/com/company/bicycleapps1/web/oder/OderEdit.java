package com.company.bicycleapps1.web.oder;

import com.haulmont.cuba.gui.components.AbstractEditor;
import com.company.bicycleapps1.entity.Oder;

public class OderEdit extends AbstractEditor<Oder> {
}