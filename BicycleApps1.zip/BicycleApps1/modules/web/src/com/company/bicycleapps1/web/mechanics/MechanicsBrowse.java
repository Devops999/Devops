package com.company.bicycleapps1.web.mechanics;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class MechanicsBrowse extends AbstractLookup {
}