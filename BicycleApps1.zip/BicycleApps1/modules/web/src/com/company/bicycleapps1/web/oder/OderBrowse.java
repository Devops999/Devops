package com.company.bicycleapps1.web.oder;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class OderBrowse extends AbstractLookup {
}