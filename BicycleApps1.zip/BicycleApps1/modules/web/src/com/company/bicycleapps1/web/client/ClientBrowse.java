package com.company.bicycleapps1.web.client;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class ClientBrowse extends AbstractLookup {
}