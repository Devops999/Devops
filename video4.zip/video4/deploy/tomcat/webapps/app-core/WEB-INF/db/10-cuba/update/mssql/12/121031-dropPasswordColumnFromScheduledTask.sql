-- Description: drop USER_PASSWORD column from SYS_SCHEDULED_TASK

alter table SYS_SCHEDULED_TASK drop column USER_PASSWORD^