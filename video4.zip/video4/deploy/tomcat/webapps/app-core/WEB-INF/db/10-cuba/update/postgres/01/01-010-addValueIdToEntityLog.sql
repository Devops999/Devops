-- Description:

alter table SEC_ENTITY_LOG_ATTR add column VALUE_ID uuid;