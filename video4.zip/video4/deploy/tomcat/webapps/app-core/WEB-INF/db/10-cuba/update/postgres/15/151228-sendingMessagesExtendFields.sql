alter table SYS_SENDING_MESSAGE alter column ADDRESS_TO type text^
alter table SYS_SENDING_MESSAGE alter column ATTACHMENTS_NAME type text^

