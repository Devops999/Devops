alter table SYS_CATEGORY_ATTR add WIDTH varchar2(20)^
alter table SYS_CATEGORY_ATTR add ROWS_COUNT integer^
