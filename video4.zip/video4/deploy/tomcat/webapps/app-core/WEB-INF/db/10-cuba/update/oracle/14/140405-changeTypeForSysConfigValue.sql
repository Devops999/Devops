-- Description: Increase max configuration parameter value length to unlimited

alter table SYS_CONFIG modify (VALUE clob) ^