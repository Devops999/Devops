alter table SYS_CATEGORY_ATTR add JOIN_CLAUSE varchar2(4000)^
alter table SYS_CATEGORY_ATTR add WHERE_CLAUSE varchar2(4000)^