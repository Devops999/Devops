alter table SEC_CONSTRAINT add column IS_ACTIVE boolean default true^

