alter table SEC_FILTER add GLOBAL_DEFAULT boolean^
update SEC_FILTER set GLOBAL_DEFAULT = false^
