
alter table SEC_CONSTRAINT alter column WHERE_CLAUSE type varchar(1000)^