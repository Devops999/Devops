package com.company.video4.web.customer;

import com.haulmont.cuba.gui.components.AbstractEditor;
import com.company.video4.entity.Customer;

public class CustomerEdit extends AbstractEditor<Customer> {
}