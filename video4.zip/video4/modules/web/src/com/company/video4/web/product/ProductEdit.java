package com.company.video4.web.product;

import com.haulmont.cuba.gui.components.AbstractEditor;
import com.company.video4.entity.Product;

public class ProductEdit extends AbstractEditor<Product> {
}