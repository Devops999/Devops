package com.company.video4.web.orderline;

import com.haulmont.cuba.gui.components.AbstractEditor;
import com.company.video4.entity.OrderLine;

public class OrderLineEdit extends AbstractEditor<OrderLine> {
}