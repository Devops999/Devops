package com.company.video4.web.order;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class OrderBrowse extends AbstractLookup {
}