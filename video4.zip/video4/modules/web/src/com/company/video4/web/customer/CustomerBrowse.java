package com.company.video4.web.customer;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class CustomerBrowse extends AbstractLookup {
}